
// crypto jars 
const imagesWrapper = document.querySelector('.jarwrapper');
const jarSlideContainer = document.querySelector('.jar-slidecontainer');

// Variables for managing slider state
let currentIndex = 0;
const totalImages = document.querySelectorAll('.jar').length;

// Create the indicator container
const indicatorContainer = document.createElement('div');
indicatorContainer.style.position = 'absolute';
indicatorContainer.style.bottom = '10px';
indicatorContainer.style.left = '50%';
indicatorContainer.style.transform = 'translateX(-50%)';
indicatorContainer.style.display = 'flex';
indicatorContainer.style.gap = '8px';

// Create individual indicators (span elements)
const indicators = [];
for (let i = 0; i < totalImages; i++) {
  const span = document.createElement('span');
  span.style.width = '5px';
  span.style.height = '5px';
  span.style.borderRadius = '50%';
  span.style.backgroundColor = i === 0 ? '#007BFF' : '#CCC'; // Highlight the first indicator
  span.style.transition = 'background-color 0.3s ease';
  indicatorContainer.appendChild(span);
  indicators.push(span);
}

// Append the indicator container to the jar-slidecontainer
jarSlideContainer.appendChild(indicatorContainer);

// Function to update the slider position
function updateSlider() {
  // Translate the wrapper to show the current image
  imagesWrapper.style.transform = `translateX(-${currentIndex * 100}%)`;
  updateIndicators(); // Update the active indicator
}

// Function to update the active indicator
function updateIndicators() {
  indicators.forEach((span, index) => {
    span.style.backgroundColor = index === currentIndex ? '#007BFF' : '#CCC';
  });
}

// Manual sliding using touch events
let startX = 0;
let endX = 0;

imagesWrapper.addEventListener('touchstart', (e) => {
  startX = e.touches[0].clientX;
});

imagesWrapper.addEventListener('touchmove', (e) => {
  endX = e.touches[0].clientX;
});

imagesWrapper.addEventListener('touchend', () => {
  const threshold = 50; // Minimum swipe distance to trigger a slide
  if (startX - endX > threshold) {
    // Swipe left
    currentIndex = (currentIndex + 1) % totalImages;
  } else if (endX - startX > threshold) {
    // Swipe right
    currentIndex = (currentIndex - 1 + totalImages) % totalImages;
  }
  updateSlider();
});

// Initialize the slider and indicators
updateSlider();














var profiler = document.querySelector('.profile');
var modal = document.querySelector('.modaltoselectprofilephotos');

let isClicked = false;

function toggleState() {
  if (isClicked) {
    modal.style.visibility = 'visible'; 
  } else {
    modal.style.display = 'hidden';
  }
}

profiler.addEventListener('click', function(event) {
  // Prevent click event from propagating to the window (so the modal doesn't close immediately)
  event.stopPropagation();

  console.log('Profile clicked');
  isClicked = !isClicked;
  toggleState();
});

window.addEventListener('click', function(event) {
  // Check if the click is outside the modal and profile
  if (!modal.contains(event.target) && !profiler.contains(event.target)) {
    isClicked = false;
    modal.style.visibility = 'hidden'; // Close the modal when clicking outside
    console.log('Clicked outside modal');
  }
});



// event listener for settings
var settings=document.querySelector('.settings');

var modalforsettings=document.querySelector('.modalforsettings');

settings.addEventListener('click',function(){
  modalforsettings.style.left='0';
});










// the photos lifters and the photos and the holder
const liftallphotos=document.getElementById('liftallphotos');


for (let i = 1; i <= 201; i++) {
  const holder = document.createElement('main'); 
  // Create a <main> element
  holder.className='mainholder';
  liftallphotos.appendChild(holder); // Append the element to the lift all photos
  
 
  
   // Add styles to the holder
 holder.style.width = "90px";
 holder.style.height = "90px";
 holder.style.background = "rgba(0,0,0,0.5)";
 holder.style.top='10px';
 holder.style.position = "relative";
  holder.style.overflow="hidden";
  holder.style.display = 'flex';
holder.style.alignItems = 'center'; // Vertically align items
holder.style.justifyContent = 'center'; // Horizontally align items
}

// the photos
const Profileimages = new Array(200).fill(""); // Create an array with 200 empty strings

// Replace placeholders with actual image URLs
Profileimages[0] = "/Xcryptos project /0x09440505229f181a6dcd6b84633bbc471f8f9c62.png";
Profileimages[1] = "/Xcryptos project /1_1MJiY10VtLV9gwHrz1vqbQ.png";
Profileimages[2] = "/Xcryptos project /1_3kHd0LnFHh0VQodsui3Dyw.png";
Profileimages[3] = "/Xcryptos project /1_KCUE03KqICaasBkZsjjM0Q.jpg";
Profileimages[4] = "/Xcryptos project /2c8d3586896371.Y3JvcCw5ODQsNzY5LDE3LDA.jpg";
Profileimages[5] = "/Xcryptos project /3d-boy-with-bitcoin-3d-image-isolated-white-background_591769-1098.jpg";
Profileimages[6] = "/Xcryptos project /3d-business-man-office-work_998340-8370.jpg";
Profileimages[7] = "/Xcryptos project /3d-business-woman-executive-pose-sitting-with-laptop-thinking-about-idea-isolated_159562-415.jpg";
Profileimages[8] = "/Xcryptos project /3d-businessmen-with-bitcoins-white-background-3d-rendering_591769-1122.jpg";   
Profileimages[9] = "/Xcryptos project /3d-character-business-woman_935410-575.jpg";
Profileimages[10] = "/Xcryptos project /3d-character-business-woman_935410-589.jpg";
Profileimages[11] = "/Xcryptos project /3d-cute-young-businesswoman-working-with-laptop_935004-1092.jpg";
Profileimages[12] = "/Xcryptos project /3d-flat-icon-investor-crytocurrency-concept-happy-group-business-professionals-attending-co_980716-69322.jpg";
Profileimages[13] = "/Xcryptos project /3d-flat-icon-investor-crytocurrency-concept-happy-man-holding-physical-bitcoin-coin-as-symbo_980716-69344.jpg";
Profileimages[14] = "/Xcryptos project /3d-illustration-business-man-standing-with-hands-his-hips_1142-54701.jpg";
Profileimages[15] = "/Xcryptos project /3d-illustration-business-woman-show-shrugging-gesture-confuse_537883-692.jpg";
Profileimages[16] = "/Xcryptos project /3d-illustration-of-bitcoin-with-up-and-down-arrows-bull-or-bear-market-trend-in-crypto-currency-or-stocks-trade-exchange-background-up-or-down-arrow-3d-rendering-png.png";
Profileimages[17] = "/Xcryptos project /3d-illustration-young-girl-working-laptop_588520-40.jpg";
Profileimages[18] = "/Xcryptos project /3d-render-little-boy-with-ethereum-coin-isolated-white-background_591769-1121.jpg";
Profileimages[19] = "/Xcryptos project /473c50c861c797977ac08497515e1a82.jpg";
Profileimages[20] = "/Xcryptos project /6273693-1.png";
Profileimages[21] = "/Xcryptos project /8e51f0b316e232e091e2f11154dc4f71.jpg";
Profileimages[22] = "/Xcryptos project /a1df10a4-1d63-4042-8ecc-b79e87eb3b0f.png";
Profileimages[23] = "/Xcryptos project /aee85a_a068d8ad985246c89040e8bb24bd63ee~mv2.png";
Profileimages[24] = "/Xcryptos project /All-You-Need-to-Know-about-Bitcoin-Crash-Game.jpg";
Profileimages[25] = "/Xcryptos project /beautful-girl-cartoon-4k_766363-143.jpg";
Profileimages[26] = "/Xcryptos project /bitcoin-4021595-3337482@0.png";
Profileimages[27] = "/Xcryptos project /bitcoin-exchange-6991902-5715491.png";
Profileimages[28] = "/Xcryptos project /boy-holding-ethereum-using-vr-tech-4812271-4003348.png";
Profileimages[29] = "/Xcryptos project /bring-your-favorite-games-home-with-our-engaging-free-png.png";
Profileimages[30] = "/Xcryptos project /business-employee-relaxing-at-work-5513542-4602547.png";
Profileimages[31] = "/Xcryptos project /business-girl-with-investment-finance-concept-3d-rendering_1031523-6390.jpg";
Profileimages[32] = "/Xcryptos project /business-girl-with-investment-finance-concept-3d-rendering_977617-16584.jpg";
Profileimages[33] = "/Xcryptos project /business-guy-sitting-using-laptop-3d-animation-style-cartoon-character-illustration_839035-118541.jpg";
Profileimages[34] = "/Xcryptos project /business-guy-sitting-using-laptop-3d-animation-style-cartoon-character-illustration_839035-118547.jpg";
Profileimages[35] = "/Xcryptos project /business-guy-sitting-using-laptop-3d-animation-style-cartoon-character-illustration_839035-118575.jpg";
Profileimages[36] = "/Xcryptos project /business-woman-glasses-with-crossed-arms-gray-background-3d-rendering_1142-40284.jpg";
Profileimages[37] = "/Xcryptos project /business-woman-office-3d-illustration-business-concept_1142-50926.jpg";
Profileimages[38] = "/Xcryptos project /businessman-standing-with-big-bitcoin-sign_87720-2440.jpg";
Profileimages[39] = "/Xcryptos project /c52c1e55862450d2b50e3a521558876d.jpg";
Profileimages[40] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3767.jpg";
Profileimages[41] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3769.jpg";
Profileimages[42] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3774.jpg";
Profileimages[43] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3774.jpg";
Profileimages[44] = "/Xcryptos project /cartoon-businessman-working-computer-3d-illustration_764664-27724.jpg";
Profileimages[45] = "/Xcryptos project /cartoon-girl-with-glasses-dollar-bill-front-bunch-coins_1103290-22546.jpg";
Profileimages[46] = "/Xcryptos project /cartoon-little-boy-teen-person-character-mascot-with-digital-cryptocurrency-golden-bitcoin-coin-3d-rendering_476612-20304.jpg";
Profileimages[47] = "/Xcryptos project /cheerful-business-man-studio-man-gray-suit-striped-tie-3d-render_631248-2918.jpg";
Profileimages[48] = "/Xcryptos project /cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTA4L3dvcmxkZmFjZXNsYWJfY3V0ZV8zZF9yZW5kZXJfY2hhcmFjdGVyX29mX2FfcmVsYXhlZF93b21hbl93b3JraV9hZmZjOTk0Yy03ZDU4LTRhNmYtYjFjOC1iZmM1MGZhYTkzZDhfMS5qcGc.jpg";
Profileimages[49] = "/Xcryptos project /Crypto-Transparent.png";
Profileimages[50] = "/Xcryptos project /cryptocurrency-3d-illustration-free-png.png";
Profileimages[51] = "/Xcryptos project /Designer (1).png";
Profileimages[52] = "/Xcryptos project /Designer (2).png";
Profileimages[53] = "/Xcryptos project /Designer (3).png";
Profileimages[54] = "/Xcryptos project /Designer.png";
Profileimages[55] = "/Xcryptos project /dfs3goh-f7ad26bc-80c5-4911-8f8d-f9b87ec858fc.png";
Profileimages[56] = "/Xcryptos project /download-flat-illustration-digital-currencies_67813-6142.jpg";
Profileimages[57] = "/Xcryptos project /downloadfile.jpg";
Profileimages[58] = "/Xcryptos project /e2a005f4af3585231bea78da875cde3a.jpg";
Profileimages[59] = "/Xcryptos project /employee-sleeping-at-work-5513543-4602548.png";
Profileimages[60] = "/Xcryptos project /fe3eb4153765809.63358416b5dac.jpg";
Profileimages[61] = "/Xcryptos project /female-wearing-glasses-vr-making-profits-from-crypto-trading-lot-coins-piled-up-3d-rendering_532795-391.jpg";
Profileimages[62] = "/Xcryptos project /Frgn7KpXoAEL3lw.jpg";
Profileimages[63] = "/Xcryptos project /fun-casual-woman_183364-44799.jpg";
Profileimages[64] = "/Xcryptos project /gold-coin-dogecion-crypto-currency-powerful-with-arms-showing-strong-muscles-golden-technology-electronic-payment-futuristic-stock-market-blockchain-and-global-economy-boom-3d-free-vector.jpg";
Profileimages[65] = "/Xcryptos project /Group-26144-1.png";
Profileimages[66] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-2995.jpg";
Profileimages[67] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-3277.jpg";
Profileimages[68] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-9225.jpg";
Profileimages[69] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-9560.jpg";
Profileimages[70] = "/Xcryptos project /image-12.png";
Profileimages[71] = "/Xcryptos project /istockphoto-1186228212-612x612.jpg";
Profileimages[72] = "/Xcryptos project /istockphoto-1298643390-170667a.jpg";
Profileimages[73] = "/Xcryptos project /kkJcmwvaLrMWtuLEndiHhbyWo3RUajY7bb0Sy2f93fIvkRNZOBIqm7zNocQUy0qgK-upmQcu0dI1ISjmv3GKN4SNEAqCQxcancLqH4I.png";
Profileimages[74] = "/Xcryptos project /LEGENDARY_ETHEREUM_GIRL_1631629608733.jpeg";
Profileimages[75] = "/Xcryptos project /lisa-money.gif";
Profileimages[76] = "/Xcryptos project /man-looking-at-cryptocurrency-trading-desk-1-768x768.png";
Profileimages[77] = "/Xcryptos project /man-working-his-office-3d-illustration_1119-3327.jpg";
Profileimages[78] = "/Xcryptos project /man-working-while-sitting-on-desk-4864711-4051270.png";
Profileimages[79] = "/Xcryptos project /OIP (1).jpeg";
Profileimages[80] = "/Xcryptos project /OIP (2).jpeg";
Profileimages[81] = "/Xcryptos project /OIP (3).jpeg";
Profileimages[82] = "/Xcryptos project /OIP (4).jpeg";
Profileimages[83] = "/Xcryptos project /OIP (5).jpeg";
Profileimages[84] = "/Xcryptos project /OIP (6).jpeg";
Profileimages[85] = "/Xcryptos project /OIP.jpeg";
Profileimages[86] = "/Xcryptos project /pngtree-bitcoin-symbol-adds-playful-twist-to-3d-cartoon-teenager-image_13509406.png";
Profileimages[87] = "/Xcryptos project /portrait-3d-character-cartoon-cute-business-woman_935410-8543.jpg";
Profileimages[88] = "/Xcryptos project /R (1).png";
Profileimages[89] = "/Xcryptos project /R.jpeg";
Profileimages[90] = "/Xcryptos project /R.png";
Profileimages[91] = "/Xcryptos project /Rare_Lite_Girl_1631390470701.jpeg";
Profileimages[92] = "/Xcryptos project /Rare_Tether_Girl_1631390561515 (1).jpeg";
Profileimages[93] = "/Xcryptos project /Rare_Tether_Girl_1631390561515 (2).jpeg";
Profileimages[94] = "/Xcryptos project /Rare_Tether_Girl_1631390561515.jpeg";
Profileimages[95] = "/Xcryptos project /richest-bitcoiners-sitting-on-a-fat-stack-of-coins-1-1024x690.jpg";
Profileimages[96] = "/Xcryptos project /smiling-3d-cartoon-business-boy_1114948-28004.jpg";
Profileimages[97] = "/Xcryptos project /st,small,507x507-pad,600x600,f8f8f8.jpg";
Profileimages[98] = "/Xcryptos project /th (1).jpeg";
Profileimages[99] = "/Xcryptos project /th (10).jpeg";
Profileimages[100] = "/Xcryptos project /th (11).jpeg";
Profileimages[101] = "/Xcryptos project /th (12).jpeg";
Profileimages[102] = "/Xcryptos project /th (13).jpeg";
Profileimages[103] = "/Xcryptos project /th (14).jpeg";
Profileimages[104] = "/Xcryptos project /th (15).jpeg";
Profileimages[105] = "/Xcryptos project /th (16).jpeg";
Profileimages[106] = "/Xcryptos project /th (17).jpeg";
Profileimages[107] = "/Xcryptos project /th (18).jpeg";
Profileimages[108] = "/Xcryptos project /th (19).jpeg";
Profileimages[109] = "/Xcryptos project /th (2).jpeg";
Profileimages[110] = "/Xcryptos project /th (20).jpeg";
Profileimages[111] = "/Xcryptos project /th (21).jpeg";
Profileimages[112] = "/Xcryptos project /th (22).jpeg";
Profileimages[113] = "/Xcryptos project /th (23).jpeg";
Profileimages[114] = "/Xcryptos project /th (24).jpeg";
Profileimages[115] = "/Xcryptos project /th (25).jpeg";
Profileimages[116] = "/Xcryptos project /th (26).jpeg";
Profileimages[117] = "/Xcryptos project /th (27).jpeg";
Profileimages[118] = "/Xcryptos project /th (28).jpeg";
Profileimages[119] = "/Xcryptos project /th (29).jpeg";
Profileimages[120] = "/Xcryptos project /th (3).jpeg";
Profileimages[121] = "/Xcryptos project /th (30).jpeg";
Profileimages[122] = "/Xcryptos project /th (31).jpeg";
Profileimages[123] = "/Xcryptos project /th (32).jpeg";
Profileimages[124] = "/Xcryptos project /th (33).jpeg";
Profileimages[125] = "/Xcryptos project /th (34).jpeg";
Profileimages[126] = "/Xcryptos project /th (35).jpeg";
Profileimages[127] = "/Xcryptos project /th (36).jpeg";
Profileimages[128] = "/Xcryptos project /th (37).jpeg";
Profileimages[129] = "/Xcryptos project /th (38).jpeg";
Profileimages[130] = "/Xcryptos project /th (39).jpeg";
Profileimages[131] = "/Xcryptos project /th (4).jpeg";
Profileimages[132] = "/Xcryptos project /th (40).jpeg";
Profileimages[133] = "/Xcryptos project /th (41).jpeg";
Profileimages[134] = "/Xcryptos project /th (42).jpeg";
Profileimages[135] = "/Xcryptos project /th (43).jpeg";
Profileimages[136] = "/Xcryptos project /th (44).jpeg";
Profileimages[137] = "/Xcryptos project /th (45).jpeg";
Profileimages[138] = "/Xcryptos project /th (46).jpeg";
Profileimages[139] = "/Xcryptos project /th (47).jpeg";
Profileimages[140] = "/Xcryptos project /th (48).jpeg";
Profileimages[141] = "/Xcryptos project /th (49).jpeg";
Profileimages[142] = "/Xcryptos project /th (5).jpeg";
Profileimages[143] = "/Xcryptos project /th (50).jpeg";
Profileimages[144] = "/Xcryptos project /th (51).jpeg";
Profileimages[145] = "/Xcryptos project /th (52).jpeg";
Profileimages[146] = "/Xcryptos project /th (53).jpeg";
Profileimages[147] = "/Xcryptos project /th (54).jpeg";
Profileimages[148] = "/Xcryptos project /th (55).jpeg";
Profileimages[149] = "/Xcryptos project /th (56).jpeg";
Profileimages[150] = "/Xcryptos project /th (57).jpeg";
Profileimages[151] = "/Xcryptos project /th (58).jpeg";
Profileimages[152] = "/Xcryptos project /th (59).jpeg";
Profileimages[153] = "/Xcryptos project /th (6).jpeg";
Profileimages[154] = "/Xcryptos project /th (60).jpeg";
Profileimages[155] = "/Xcryptos project /th (61).jpeg";
Profileimages[156] = "/Xcryptos project /th (62).jpeg";
Profileimages[157] = "/Xcryptos project /th (63).jpeg";
Profileimages[158] = "/Xcryptos project /th (64).jpeg";
Profileimages[159] = "/Xcryptos project /th (65).jpeg";
Profileimages[160] = "/Xcryptos project /th (66).jpeg";
Profileimages[161] = "/Xcryptos project /th (67).jpeg";
Profileimages[162] = "/Xcryptos project /th (68).jpeg";
Profileimages[163] = "/Xcryptos project /th (69).jpeg";
Profileimages[164] = "/Xcryptos project /th (7).jpeg";
Profileimages[165] = "/Xcryptos project /th (70).jpeg";
Profileimages[166] = "/Xcryptos project /th (71).jpeg";
Profileimages[167] = "/Xcryptos project /th (72).jpeg";
Profileimages[168] = "/Xcryptos project /th (73).jpeg";
Profileimages[169] = "/Xcryptos project /th (74).jpeg";
Profileimages[170] = "/Xcryptos project /th (75).jpeg";
Profileimages[171] = "/Xcryptos project /th (76).jpeg";
Profileimages[172] = "/Xcryptos project /th (77).jpeg";
Profileimages[173] = "/Xcryptos project /th (78).jpeg";
Profileimages[174] = "/Xcryptos project /th (79).jpeg";
Profileimages[175] = "/Xcryptos project /th (8).jpeg";
Profileimages[176] = "/Xcryptos project /th (80).jpeg";
Profileimages[177] = "/Xcryptos project /th (81).jpeg";
Profileimages[178] = "/Xcryptos project /th (82).jpeg";
Profileimages[179] = "/Xcryptos project /th (83).jpeg";
Profileimages[180] = "/Xcryptos project /th (84).jpeg";
Profileimages[181] = "/Xcryptos project /th (85).jpeg";
Profileimages[182] = "/Xcryptos project /th (86).jpeg";
Profileimages[183] = "/Xcryptos project /th (87).jpeg";
Profileimages[184] = "/Xcryptos project /th (88).jpeg";
Profileimages[185] = "/Xcryptos project /th (89).jpeg";
Profileimages[186] = "/Xcryptos project /th (9).jpeg";
Profileimages[187] = "/Xcryptos project /th.jpeg";
Profileimages[188] = "/Xcryptos project /Tron_Girl_1631389926159.jpeg";
Profileimages[189] = "/Xcryptos project /view-3d-businessman-working-laptop_23-2150709808.jpg";
Profileimages[190] = "/Xcryptos project /woman-playing-gaming-7900653-6397256.png";
Profileimages[191] = "/Xcryptos project /woman-with-bitcoins-flying-vector.jpg";
Profileimages[192] = "/Xcryptos project /woman-with-dollar-bill-her-hand-is-standing-front-pile-coins_1103290-25585.jpg";
Profileimages[193] = "/Xcryptos project /young-man-red-haired-have-found-an-idea-3d-character-illustration-png.png";
Profileimages[194] = "/Xcryptos project /young-woman-ann-attending-online-conference-3d-vector-illustration_1036687-51907.jpg";
Profileimages[195] = "/Xcryptos project /young-woman-ann-attending-online-conference-3d-vector-illustration_1036687-51945.jpg";
Profileimages[196] = "https://example.com/image47.jpg";
Profileimages[197] = "https://example.com/image48.jpg";
Profileimages[198] = "https://example.com/image49.jpg";
Profileimages[199] = "https://example.com/image50.jpg";

Profileimages[200] = "https://example.com/image200.jpg"; // Last image







// looping and append
document.querySelectorAll(".mainholder").forEach((holder, index) => {
  if (index < Profileimages.length) {
    // Create an image element and set its source
    const img = document.createElement("img");
    img.src = Profileimages[index];
    img.alt = `Profile Image ${index + 1}`;
    img.style.width = "100%";
    img.style.height = "100%";
    img.style.position="inherit";
    img.style.objectFit = "cover"; // Ensures the image fits nicely

    // Append the image to the holder
    holder.appendChild(img);

    // Add an event listener to the holder (e.g., for clicks)
    holder.addEventListener("click", () => {
      console.log('you clicked on the holder');
    });
  }
});


// create device photo button to take users to device photos
const devicephotosButtondiv=document.createElement('div');
devicephotosButtondiv.id='devicephotos';

devicephotosButtondiv.style.width='150px';
devicephotosButtondiv.style.height='150px';
devicephotosButtondiv.style.position='absolute';
devicephotosButtondiv.style.background='rgba(0,0,0,0.5)';

devicephotosButtondiv.style.display='none';

liftallphotos.appendChild(devicephotosButtondiv);




















// deposit click transfer click and walet clicks
const things = document.querySelectorAll('.things');
const slidedown = document.createElement('label');

// Style the slidedown element
slidedown.style.backgroundColor = '#fff';
slidedown.style.width = '65px';
slidedown.style.height = '6px';
slidedown.style.borderRadius = '20px';
slidedown.style.position = 'absolute';
slidedown.style.top = '2px';

// Loop through each "things" element
things.forEach(thing => {
  thing.addEventListener('click', () => {
    // Get the ID of the clicked element
    const thingId = thing.id;

    // Select all tables
    const allTables = document.querySelectorAll('.yatchtable');

    // Add a transition effect to all tables
    allTables.forEach(table => {
      table.style.transition = 'all 0.3s ease-in-out';
    });

    // Get the target table
    const target = thing.getAttribute('data-target');
    const targetTable = document.getElementById(target);

    if (targetTable) {
      // Set up the target table
      targetTable.style.visibility = 'visible';
      targetTable.style.bottom = '0';

      // Modify height for the specific "things"
      if (thingId === 'things1') {
        targetTable.style.height = '45%'; // Default height for "things1"
      } else if (thingId === 'things2') {
        targetTable.style.height = '90%'; // Custom height for "things2"
      } else if (thingId === 'things3') {
        targetTable.style.height = '60%'; 
      } else if(thingId === 'things4'){
        targetTable.style.height = '100%'; 
        targetTable.style.borderRadius='0';
        
      } else if(thingId ==='things5'){
        targetTable.style.height = '100%';
        targetTable.style.borderRadius='0';
      }

      // Append the slidedown handle
      targetTable.appendChild(slidedown);

      // Variables to track touch gestures
      let startY = 0;
      let endY = 0;

      const handleTouchStart = (e) => {
        startY = e.touches[0].clientY;
      };

      const handleTouchMove = (e) => {
        endY = e.touches[0].clientY;
        const deltaY = endY - startY;

        // Adjust bottom position as user slides
        if (deltaY > 0 && deltaY < 300) {
          targetTable.style.bottom = `-${deltaY}px`;
        } else if (deltaY < 0 && deltaY > -300) {
          targetTable.style.bottom = `${-deltaY}px`;
        }
      };

      const handleTouchEnd = () => {
        const deltaY = endY - startY;

        // Determine final position
        if (deltaY > 150) {
          targetTable.style.bottom = '-100%'; // Hide
        } else {
          targetTable.style.bottom = '0'; // Reset to visible
        }
      };

      // Attach touch events to both targetTable and slidedown
      [targetTable, slidedown].forEach(element => {
        element.addEventListener('touchstart', handleTouchStart);
        element.addEventListener('touchmove', handleTouchMove);
        element.addEventListener('touchend', handleTouchEnd);
      });
    }

    // Hide all other tables except the target one
    allTables.forEach(table => {
      if (table.id !== thing.getAttribute('data-target')) {
        table.style.visibility = 'hidden';
        table.style.bottom = '-200px';
        table.style.height = '25%'; // Reset height
      }
    });
  });
});




// detect device informations for further recognitions stuffs
// Function to collect device information
function setCookie(name, value, days = 1) {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000); // Set expiration
  document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/`;
}

function getCookie(name) {
  const cookieArr = document.cookie.split("; ");
  for (const cookie of cookieArr) {
    const [key, value] = cookie.split("=");
    if (key === name) return value;
  }
  return null;
}

async function manageDevice() {
  // Retrieve the device ID from the cookie
  let activeDeviceId = getCookie("activeDeviceId");

  if (activeDeviceId) {
    // If an ID exists, log recognition
    console.log("Device is recognized with ID:");
    return; // Stop further execution
  }

  // If no ID exists, detect the device and assign an ID
  const deviceInfo = await detectDeviceInfo();
  activeDeviceId = generateUniqueId();
  setCookie("activeDeviceId", activeDeviceId, 1); // Store the ID in a cookie
  console.log("New Device Detected and Assigned ID:", activeDeviceId);
  console.log("Detected Device Info:", deviceInfo);
}

function generateUniqueId() {
  return `device-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

async function detectDeviceInfo() {
  const deviceInfo = {
    browser: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    connectionType: navigator.connection ? navigator.connection.effectiveType : "unknown",
    online: navigator.onLine,
    ip: await getPublicIp(),
  };
  return deviceInfo;
}

async function getPublicIp() {
  try {
    const response = await fetch("https://api64.ipify.org?format=json");
    const data = await response.json();
    return data.ip;
  } catch (err) {
    console.error("Error fetching IP:", err);
    return "Unable to fetch IP";
  }
}

// Run the manageDevice function
manageDevice();













// price updates
const apiKey = '007956b366cca4c6f59f2ba7d702a279f2048b7893e8bbf6bd64d504a085193d'; 
const url = 'https://min-api.cryptocompare.com/data/pricemulti';

const fetchAllToUSD = async () => {
  const cryptos = ['BTC', 'ETH', 'DOGE', 'ADA', 'XRP']; // List of cryptocurrencies
  const currency = 'USD'; // Target currency (USD)

  try {
    const response = await fetch(`${url}?fsyms=${cryptos.join(',')}&tsyms=${currency}`, {
      headers: {
        authorization: `Apikey ${apiKey}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Prices of cryptocurrencies in USD:', data);
  } catch (error) {
    console.error('Failed to fetch prices:', error);
  }
};

// Fetch prices for all listed cryptocurrencies
fetchAllToUSD();