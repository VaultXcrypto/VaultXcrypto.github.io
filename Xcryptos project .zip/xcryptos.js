const pay=document.querySelector('#pay');
const modalfortranscts=document.querySelector('#modalfortransacts');

pay.addEventListener('click',function(){
  modalfortranscts.style.bottom='0';
});



window.onload = function() {
  // Your code here
  console.log("Window has loaded!");
};