const p2pbuyers = document.createElement('p');
p2pbuyers.innerHTML = '$1,000,000.00';
p2pbuyers.style.fontSize = '17px';
p2pbuyers.style.position = 'absolute';
p2pbuyers.style.top = '100px';



document.addEventListener("DOMContentLoaded", () => {
  const persons = document.querySelectorAll(".person");
  const sections = document.querySelectorAll(".content-section");
  const buyersList = document.getElementById("buyers-list");
  const loadBuyersBtn = document.getElementById("load-buyers");
  const tradersList = document.getElementById("traders-list");

  // Constants
  const totalBuyers = 2000000; // Total buyers
  const buyersPerPage = 100; // Buyers per page to load
  const totalTraders = 100; // Total number of traders

  let currentBuyerPage = 0; // Track the current page of buyers being shown

  // Simulate an array of 2 million buyers (just for rendering, can be dynamic)
  const allBuyers = Array.from({ length: totalBuyers }, (_, index) => `Buyer ${index + 1}`);

  // Arrays for first and last names
  const firstNames = ["John", "Jane", "Alice", "Bob", "Charlie", "David", "Eva", "Frank", "Grace", "Hannah", "Ivy", "Jack", "Kate", "Leo", "Mia", "Nina", "Oscar", "Paul", "Quinn", "Rachel", "Sam", "Tom", "Uma", "Vera", "Will", "Xander", "Yara", "Zane", "Alex", "Brooklyn"];
  const lastNames = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Miller", "Davis", "García", "Rodriguez", "Martínez", "Hernández", "Lopez", "González", "Perez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Harris", "Clark", "Lewis", "Roberts", "Walker", "Young"];

  // Function to generate random names
  const generateRandomName = () => {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    return `${firstName} ${lastName}`;
  };

  // Function to render the buyers
  const renderBuyers = () => {
    const start = currentBuyerPage * buyersPerPage;
    const end = start + buyersPerPage;
    const buyersToRender = allBuyers.slice(start, end);

    buyersToRender.forEach((buyer, index) => {
 
      const globalIndex = start + index; // Ensure IDs are unique across pages
      const div = document.createElement("div");
      div.classList.add("eachbuyer");
      div.style.display = 'flex'; // Add flex display
      div.style.alignItems = 'center'; // Center items vertically
      buyersList.appendChild(div);

      // Create the profile div to be appended to eachbuyer
      const profile = document.createElement('div');
      profile.style.width = '45px';
      profile.style.height = '45px';
      profile.style.borderRadius = '100%';
      profile.style.border = '0.4px solid #fff';
      profile.style.position = 'absolute';
      profile.style.left = '7px';
      profile.setAttribute("id", `buyer-profile-${globalIndex}`); // Assign unique ID to each profile
      div.appendChild(profile); // Append to eachbuyer
      
      const buyerssignal=document.createElement('span');
      buyerssignal.innerHTML='want to buy';
      buyerssignal.style.background='#fff';
      buyerssignal.style.position='absolute';
      buyerssignal.style.right='10px';
      buyerssignal.style.color='green';
      buyerssignal.style.fontSize='12px';
      buyerssignal.style.paddingLeft='10px';
      buyerssignal.style.paddingRight='10px';
      buyerssignal.style.borderRadius='25px';
      div.appendChild(buyerssignal);
      
      
       // Append the profile image from the profileImages array
 const profileImage = document.createElement('img');
 profileImage.src = Profileimages[globalIndex % Profileimages.length]; // Loop through the profile images
 profileImage.style.width = '100%';
 profileImage.style.height = '100%';
 profileImage.style.objectFit='cover';
 profileImage.style.borderRadius = '100%';
 profile.appendChild(profileImage);
      
      
      

      profile.addEventListener('click', function() {
        console.log(`Profile ID clicked: ${profile.id}`);
const upnav=document.querySelector('.upnavigation');
upnav.classList.add('blur');
buyersList.classList.add('blur');
        // Create a new div (appender) and append the clicked profile's copy
        const appender = document.createElement('div');
        appender.style.width = '100%';
        appender.style.height = '100%';
        appender.style.display = 'flex';
        appender.style.alignItems = 'center';
        appender.style.position="fixed";
        appender.style.bottom='0';
        appender.style.justifyContent = 'center';
        appender.style.background = 'transparent';
        appender.style.zIndex='10';

        // Create a copy of the profile and set its styles
        const profileCopy = profile.cloneNode(true);
        profileCopy.style.width = '150px';
        profileCopy.style.height = '150px';
        profileCopy.style.position='relative';
        profileCopy.style.borderRadius = '100%';
        profileCopy.style.border = '0.4px solid #fff';

        appender.appendChild(profileCopy);

        // Append the new div to the body or another container as needed
        document.body.appendChild(appender);
        // Add the event listener to appender
appender.addEventListener('click', function(event) {
  appender.style.display = 'none'; // Corrected property
  appender.style.transition = 'all 0.3s ease-in-out';
  upnav.classList.remove('blur');
  buyersList.classList.remove('blur');
});

// Add the event listener to profileCopy once, outside the appender logic
profileCopy.addEventListener('click', function(event) {
  event.stopPropagation(); // Prevents the appender click event
});
      });
      
      

      // Create peoplenames element and append it
      const peoplenames = document.createElement('p');
      peoplenames.classList.add('peoplenamesfont');
      peoplenames.textContent = generateRandomName();
      peoplenames.style.position = 'absolute';
      peoplenames.style.left = '60px';
      peoplenames.style.color = '#fff';
      peoplenames.style.display = 'flex';
      peoplenames.style.alignItems = 'center'; // Center align the name vertically
      div.appendChild(peoplenames); // Append to eachbuyer

      // Create verified img element and append it
      const verified = document.createElement('img');
      verified.classList.add('verified');
      verified.src = '/twitter-verified-badge-svgrepo-com.svg';
      verified.style.position = 'inherit';
      verified.style.right = '-20px'; // Position it to the right
      peoplenames.appendChild(verified); // Append the verified image to peoplenames
    });

    currentBuyerPage++;

    // Disable the "Load More" button if all buyers have been loaded
    if (currentBuyerPage * buyersPerPage >= totalBuyers) {
      loadBuyersBtn.style.display = "none";
    }
  };

  // Function to create traders dynamically
  const createTraders = () => {
    for (let i = 1; i <= totalTraders; i++) {
      
      
      
      const div = document.createElement("div");
      div.classList.add("eachtrader");
      div.style.display = 'flex'; // Add flex display
      div.style.alignItems = 'center'; // Center items vertically
      tradersList.appendChild(div);

      // Create the profile div to be appended to eachtrader
      const profile = document.createElement('div');
      profile.style.width = '45px';
      profile.style.height = '45px';
      profile.style.borderRadius = '100%';
      profile.style.border = '0.4px solid #fff';
      profile.style.position = 'absolute';
      profile.style.left = '7px';
      
      div.appendChild(profile); // Append to eachtrader
      

 

      profile.addEventListener('click', function() {
        console.log(`Profile ID clicked: ${profile.id}`);
const upnav = document.querySelector('.upnavigation');
upnav.classList.add('blur');
tradersList.classList.add('blur');
        // Create a new div (appender) and append the clicked profile's copy
        const appender = document.createElement('div');
        appender.style.width = '100%';
        appender.style.height = '100%';
        appender.style.display = 'flex';
        appender.style.alignItems = 'center';
        appender.style.justifyContent = 'center';
        appender.style.position='fixed';
        appender.style.bottom='0';
        appender.style.zIndex='10';
        appender.style.background = 'transparent';

        // Create a copy of the profile and set its styles
        const profileCopy = profile.cloneNode(true);
        profileCopy.style.width = '150px';
        profileCopy.style.height = '150px';
        profileCopy.style.borderRadius = '100%';
        profileCopy.style.position='relative';
        profileCopy.style.border = '0.4px solid #fff';

        appender.appendChild(profileCopy);

        // Append the new div to the body or another container as needed
        document.body.appendChild(appender);
        appender.addEventListener('click', function(event) {
  appender.style.display = 'none'; // Corrected property
  appender.style.transition = 'all 0.3s ease-in-out';
  upnav.classList.remove('blur');
  tradersList.classList.remove('blur');
});

// Add the event listener to profileCopy once, outside the appender logic
profileCopy.addEventListener('click', function(event) {
  event.stopPropagation(); // Prevents the appender click event
});
      });

      // Create peoplenames element and append it
      const peoplenames = document.createElement('p');
      peoplenames.classList.add('peoplenamesfont');
      peoplenames.textContent = generateRandomName();
      peoplenames.style.position = 'absolute';
      peoplenames.style.left = '60px';
      peoplenames.style.color = '#fff';
      peoplenames.style.display = 'flex';
      peoplenames.style.alignItems = 'center'; // Center align the name vertically
      div.appendChild(peoplenames); // Append to eachtrader

      // Create verified img element and append it
      const verified = document.createElement('img');
      verified.classList.add('verified');
      verified.src = '/twitter-verified-badge-svgrepo-com.svg';
      verified.style.position = 'inherit';
      verified.style.right = '-20px'; // Position it to the right
      peoplenames.appendChild(verified); // Append the verified image to peoplenames
    }
  };

  // Initial render of buyers and traders
  renderBuyers();
  createTraders();

  // Load more buyers on button click
  loadBuyersBtn.addEventListener("click", renderBuyers);

  // Utility to toggle visibility of sections
  const toggleSection = (target) => {
    sections.forEach((section) => {
      if (section.id === target) {
        section.classList.add("visible");
      } else {
        section.classList.remove("visible");
      }
    });
  };

  // Add click event to navigation items
  persons.forEach((person) => {
    person.addEventListener("click", () => {
      // Remove 'active' class from all, add to clicked
      persons.forEach((p) => p.classList.remove("active"));
      person.classList.add("active");

      // Toggle visibility of the target section
      const target = person.dataset.target;
      toggleSection(target);
    });
  });

  // Default state: Show buyers section
  toggleSection("buyers");

  // Create the new div element for the sliding effect
  const newDiv = document.createElement('div');
  newDiv.style.width = '100%';
  newDiv.style.height = '100%';
  newDiv.style.position = 'fixed';
  newDiv.style.top = '0';
  newDiv.style.right = '-100%'; // Initially off-screen
  newDiv.style.backgroundColor = '#15202B';
  newDiv.style.zIndex = '10';
  newDiv.style.transition = 'right 0.3s ease-in-out';
  document.body.appendChild(newDiv);

  // Create the close button
  const closeButton = document.createElement('button');
  closeButton.textContent = 'Close';
  closeButton.style.position = 'absolute';
  closeButton.style.top = '10px';
  closeButton.style.right = '10px';
  closeButton.style.padding = '10px 20px';
  closeButton.style.backgroundColor = '#ff0000';
  closeButton.style.color = 'white';
  closeButton.style.border = 'none';
  closeButton.style.cursor = 'pointer';
  closeButton.style.borderRadius = '5px';
  newDiv.appendChild(closeButton);

  // Function to open the div
  const openNewDiv = () => {
    newDiv.style.right = '0'; // Slide in the div
  };

  // Function to close the div
  const closeNewDiv = () => {
    newDiv.style.right = '-100%'; // Slide out the div
  };

  // Event delegation: Listen to click events on the parent elements (buyersList and tradersList)
  buyersList.addEventListener('click', (event) => {
    if (event.target && (event.target.classList.contains('eachbuyer') || event.target.classList.contains('peoplenamesfont'))) {
      openNewDiv(); // Open the sliding div if an eachbuyer or peoplenames is clicked
    }
  });

  tradersList.addEventListener('click', (event) => {
    if (event.target && (event.target.classList.contains('eachtrader') || event.target.classList.contains('peoplenamesfont'))) {
      openNewDiv(); // Open the sliding div if an eachtrader or peoplenames is clicked
    }
  });

  // Close the div when the close button is clicked
  closeButton.addEventListener('click', closeNewDiv);
});








// profile images 
const Profileimages = new Array(200).fill(""); // Create an array with 200 empty strings

// Replace placeholders with actual image URLs
Profileimages[0] = "/Xcryptos project /0x09440505229f181a6dcd6b84633bbc471f8f9c62.png";
Profileimages[1] = "/Xcryptos project /1_1MJiY10VtLV9gwHrz1vqbQ.png";
Profileimages[2] = "/Xcryptos project /1_3kHd0LnFHh0VQodsui3Dyw.png";
Profileimages[3] = "/Xcryptos project /1_KCUE03KqICaasBkZsjjM0Q.jpg";
Profileimages[4] = "/Xcryptos project /2c8d3586896371.Y3JvcCw5ODQsNzY5LDE3LDA.jpg";
Profileimages[5] = "/Xcryptos project /3d-boy-with-bitcoin-3d-image-isolated-white-background_591769-1098.jpg";
Profileimages[6] = "/Xcryptos project /3d-business-man-office-work_998340-8370.jpg";
Profileimages[7] = "/Xcryptos project /3d-business-woman-executive-pose-sitting-with-laptop-thinking-about-idea-isolated_159562-415.jpg";
Profileimages[8] = "/Xcryptos project /3d-businessmen-with-bitcoins-white-background-3d-rendering_591769-1122.jpg";   
Profileimages[9] = "/Xcryptos project /3d-character-business-woman_935410-575.jpg";
Profileimages[10] = "/Xcryptos project /3d-character-business-woman_935410-589.jpg";
Profileimages[11] = "/Xcryptos project /3d-cute-young-businesswoman-working-with-laptop_935004-1092.jpg";
Profileimages[12] = "/Xcryptos project /3d-flat-icon-investor-crytocurrency-concept-happy-group-business-professionals-attending-co_980716-69322.jpg";
Profileimages[13] = "/Xcryptos project /3d-flat-icon-investor-crytocurrency-concept-happy-man-holding-physical-bitcoin-coin-as-symbo_980716-69344.jpg";
Profileimages[14] = "/Xcryptos project /3d-illustration-business-man-standing-with-hands-his-hips_1142-54701.jpg";
Profileimages[15] = "/Xcryptos project /3d-illustration-business-woman-show-shrugging-gesture-confuse_537883-692.jpg";
Profileimages[16] = "/Xcryptos project /3d-illustration-of-bitcoin-with-up-and-down-arrows-bull-or-bear-market-trend-in-crypto-currency-or-stocks-trade-exchange-background-up-or-down-arrow-3d-rendering-png.png";
Profileimages[17] = "/Xcryptos project /3d-illustration-young-girl-working-laptop_588520-40.jpg";
Profileimages[18] = "/Xcryptos project /3d-render-little-boy-with-ethereum-coin-isolated-white-background_591769-1121.jpg";
Profileimages[19] = "/Xcryptos project /473c50c861c797977ac08497515e1a82.jpg";
Profileimages[20] = "/Xcryptos project /6273693-1.png";
Profileimages[21] = "/Xcryptos project /8e51f0b316e232e091e2f11154dc4f71.jpg";
Profileimages[22] = "/Xcryptos project /a1df10a4-1d63-4042-8ecc-b79e87eb3b0f.png";
Profileimages[23] = "/Xcryptos project /aee85a_a068d8ad985246c89040e8bb24bd63ee~mv2.png";
Profileimages[24] = "/Xcryptos project /All-You-Need-to-Know-about-Bitcoin-Crash-Game.jpg";
Profileimages[25] = "/Xcryptos project /beautful-girl-cartoon-4k_766363-143.jpg";
Profileimages[26] = "/Xcryptos project /bitcoin-4021595-3337482@0.png";
Profileimages[27] = "/Xcryptos project /bitcoin-exchange-6991902-5715491.png";
Profileimages[28] = "/Xcryptos project /boy-holding-ethereum-using-vr-tech-4812271-4003348.png";
Profileimages[29] = "/Xcryptos project /bring-your-favorite-games-home-with-our-engaging-free-png.png";
Profileimages[30] = "/Xcryptos project /business-employee-relaxing-at-work-5513542-4602547.png";
Profileimages[31] = "/Xcryptos project /business-girl-with-investment-finance-concept-3d-rendering_1031523-6390.jpg";
Profileimages[32] = "/Xcryptos project /business-girl-with-investment-finance-concept-3d-rendering_977617-16584.jpg";
Profileimages[33] = "/Xcryptos project /business-guy-sitting-using-laptop-3d-animation-style-cartoon-character-illustration_839035-118541.jpg";
Profileimages[34] = "/Xcryptos project /business-guy-sitting-using-laptop-3d-animation-style-cartoon-character-illustration_839035-118547.jpg";
Profileimages[35] = "/Xcryptos project /business-guy-sitting-using-laptop-3d-animation-style-cartoon-character-illustration_839035-118575.jpg";
Profileimages[36] = "/Xcryptos project /business-woman-glasses-with-crossed-arms-gray-background-3d-rendering_1142-40284.jpg";
Profileimages[37] = "/Xcryptos project /business-woman-office-3d-illustration-business-concept_1142-50926.jpg";
Profileimages[38] = "/Xcryptos project /businessman-standing-with-big-bitcoin-sign_87720-2440.jpg";
Profileimages[39] = "/Xcryptos project /c52c1e55862450d2b50e3a521558876d.jpg";
Profileimages[40] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3767.jpg";
Profileimages[41] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3769.jpg";
Profileimages[42] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3774.jpg";
Profileimages[43] = "/Xcryptos project /cartoon-3d-business-man-office-isolated-white_744040-3774.jpg";
Profileimages[44] = "/Xcryptos project /cartoon-businessman-working-computer-3d-illustration_764664-27724.jpg";
Profileimages[45] = "/Xcryptos project /cartoon-girl-with-glasses-dollar-bill-front-bunch-coins_1103290-22546.jpg";
Profileimages[46] = "/Xcryptos project /cartoon-little-boy-teen-person-character-mascot-with-digital-cryptocurrency-golden-bitcoin-coin-3d-rendering_476612-20304.jpg";
Profileimages[47] = "/Xcryptos project /cheerful-business-man-studio-man-gray-suit-striped-tie-3d-render_631248-2918.jpg";
Profileimages[48] = "/Xcryptos project /cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTA4L3dvcmxkZmFjZXNsYWJfY3V0ZV8zZF9yZW5kZXJfY2hhcmFjdGVyX29mX2FfcmVsYXhlZF93b21hbl93b3JraV9hZmZjOTk0Yy03ZDU4LTRhNmYtYjFjOC1iZmM1MGZhYTkzZDhfMS5qcGc.jpg";
Profileimages[49] = "/Xcryptos project /Crypto-Transparent.png";
Profileimages[50] = "/Xcryptos project /cryptocurrency-3d-illustration-free-png.png";
Profileimages[51] = "/Xcryptos project /Designer (1).png";
Profileimages[52] = "/Xcryptos project /Designer (2).png";
Profileimages[53] = "/Xcryptos project /Designer (3).png";
Profileimages[54] = "/Xcryptos project /Designer.png";
Profileimages[55] = "/Xcryptos project /dfs3goh-f7ad26bc-80c5-4911-8f8d-f9b87ec858fc.png";
Profileimages[56] = "/Xcryptos project /download-flat-illustration-digital-currencies_67813-6142.jpg";
Profileimages[57] = "/Xcryptos project /downloadfile.jpg";
Profileimages[58] = "/Xcryptos project /e2a005f4af3585231bea78da875cde3a.jpg";
Profileimages[59] = "/Xcryptos project /employee-sleeping-at-work-5513543-4602548.png";
Profileimages[60] = "/Xcryptos project /fe3eb4153765809.63358416b5dac.jpg";
Profileimages[61] = "/Xcryptos project /female-wearing-glasses-vr-making-profits-from-crypto-trading-lot-coins-piled-up-3d-rendering_532795-391.jpg";
Profileimages[62] = "/Xcryptos project /Frgn7KpXoAEL3lw.jpg";
Profileimages[63] = "/Xcryptos project /fun-casual-woman_183364-44799.jpg";
Profileimages[64] = "/Xcryptos project /gold-coin-dogecion-crypto-currency-powerful-with-arms-showing-strong-muscles-golden-technology-electronic-payment-futuristic-stock-market-blockchain-and-global-economy-boom-3d-free-vector.jpg";
Profileimages[65] = "/Xcryptos project /Group-26144-1.png";
Profileimages[66] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-2995.jpg";
Profileimages[67] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-3277.jpg";
Profileimages[68] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-9225.jpg";
Profileimages[69] = "/Xcryptos project /happy-3d-business-man-transparent-white-background_457222-9560.jpg";
Profileimages[70] = "/Xcryptos project /image-12.png";
Profileimages[71] = "/Xcryptos project /istockphoto-1186228212-612x612.jpg";
Profileimages[72] = "/Xcryptos project /istockphoto-1298643390-170667a.jpg";
Profileimages[73] = "/Xcryptos project /kkJcmwvaLrMWtuLEndiHhbyWo3RUajY7bb0Sy2f93fIvkRNZOBIqm7zNocQUy0qgK-upmQcu0dI1ISjmv3GKN4SNEAqCQxcancLqH4I.png";
Profileimages[74] = "/Xcryptos project /LEGENDARY_ETHEREUM_GIRL_1631629608733.jpeg";
Profileimages[75] = "/Xcryptos project /lisa-money.gif";
Profileimages[76] = "/Xcryptos project /man-looking-at-cryptocurrency-trading-desk-1-768x768.png";
Profileimages[77] = "/Xcryptos project /man-working-his-office-3d-illustration_1119-3327.jpg";
Profileimages[78] = "/Xcryptos project /man-working-while-sitting-on-desk-4864711-4051270.png";
Profileimages[79] = "/Xcryptos project /OIP (1).jpeg";
Profileimages[80] = "/Xcryptos project /OIP (2).jpeg";
Profileimages[81] = "/Xcryptos project /OIP (3).jpeg";
Profileimages[82] = "/Xcryptos project /OIP (4).jpeg";
Profileimages[83] = "/Xcryptos project /OIP (5).jpeg";
Profileimages[84] = "/Xcryptos project /OIP (6).jpeg";
Profileimages[85] = "/Xcryptos project /OIP.jpeg";
Profileimages[86] = "/Xcryptos project /pngtree-bitcoin-symbol-adds-playful-twist-to-3d-cartoon-teenager-image_13509406.png";
Profileimages[87] = "/Xcryptos project /portrait-3d-character-cartoon-cute-business-woman_935410-8543.jpg";
Profileimages[88] = "/Xcryptos project /R (1).png";
Profileimages[89] = "/Xcryptos project /R.jpeg";
Profileimages[90] = "/Xcryptos project /R.png";
Profileimages[91] = "/Xcryptos project /Rare_Lite_Girl_1631390470701.jpeg";
Profileimages[92] = "/Xcryptos project /Rare_Tether_Girl_1631390561515 (1).jpeg";
Profileimages[93] = "/Xcryptos project /Rare_Tether_Girl_1631390561515 (2).jpeg";
Profileimages[94] = "/Xcryptos project /Rare_Tether_Girl_1631390561515.jpeg";
Profileimages[95] = "/Xcryptos project /richest-bitcoiners-sitting-on-a-fat-stack-of-coins-1-1024x690.jpg";
Profileimages[96] = "/Xcryptos project /smiling-3d-cartoon-business-boy_1114948-28004.jpg";
Profileimages[97] = "/Xcryptos project /st,small,507x507-pad,600x600,f8f8f8.jpg";
Profileimages[98] = "/Xcryptos project /th (1).jpeg";
Profileimages[99] = "/Xcryptos project /th (10).jpeg";
Profileimages[100] = "/Xcryptos project /th (11).jpeg";
Profileimages[101] = "/Xcryptos project /th (12).jpeg";
Profileimages[102] = "/Xcryptos project /th (13).jpeg";
Profileimages[103] = "/Xcryptos project /th (14).jpeg";
Profileimages[104] = "/Xcryptos project /th (15).jpeg";
Profileimages[105] = "/Xcryptos project /th (16).jpeg";
Profileimages[106] = "/Xcryptos project /th (17).jpeg";
Profileimages[107] = "/Xcryptos project /th (18).jpeg";
Profileimages[108] = "/Xcryptos project /th (19).jpeg";
Profileimages[109] = "/Xcryptos project /th (2).jpeg";
Profileimages[110] = "/Xcryptos project /th (20).jpeg";
Profileimages[111] = "/Xcryptos project /th (21).jpeg";
Profileimages[112] = "/Xcryptos project /th (22).jpeg";
Profileimages[113] = "/Xcryptos project /th (23).jpeg";
Profileimages[114] = "/Xcryptos project /th (24).jpeg";
Profileimages[115] = "/Xcryptos project /th (25).jpeg";
Profileimages[116] = "/Xcryptos project /th (26).jpeg";
Profileimages[117] = "/Xcryptos project /th (27).jpeg";
Profileimages[118] = "/Xcryptos project /th (28).jpeg";
Profileimages[119] = "/Xcryptos project /th (29).jpeg";
Profileimages[120] = "/Xcryptos project /th (3).jpeg";
Profileimages[121] = "/Xcryptos project /th (30).jpeg";
Profileimages[122] = "/Xcryptos project /th (31).jpeg";
Profileimages[123] = "/Xcryptos project /th (32).jpeg";
Profileimages[124] = "/Xcryptos project /th (33).jpeg";
Profileimages[125] = "/Xcryptos project /th (34).jpeg";
Profileimages[126] = "/Xcryptos project /th (35).jpeg";
Profileimages[127] = "/Xcryptos project /th (36).jpeg";
Profileimages[128] = "/Xcryptos project /th (37).jpeg";
Profileimages[129] = "/Xcryptos project /th (38).jpeg";
Profileimages[130] = "/Xcryptos project /th (39).jpeg";
Profileimages[131] = "/Xcryptos project /th (4).jpeg";
Profileimages[132] = "/Xcryptos project /th (40).jpeg";
Profileimages[133] = "/Xcryptos project /th (41).jpeg";
Profileimages[134] = "/Xcryptos project /th (42).jpeg";
Profileimages[135] = "/Xcryptos project /th (43).jpeg";
Profileimages[136] = "/Xcryptos project /th (44).jpeg";
Profileimages[137] = "/Xcryptos project /th (45).jpeg";
Profileimages[138] = "/Xcryptos project /th (46).jpeg";
Profileimages[139] = "/Xcryptos project /th (47).jpeg";
Profileimages[140] = "/Xcryptos project /th (48).jpeg";
Profileimages[141] = "/Xcryptos project /th (49).jpeg";
Profileimages[142] = "/Xcryptos project /th (5).jpeg";
Profileimages[143] = "/Xcryptos project /th (50).jpeg";
Profileimages[144] = "/Xcryptos project /th (51).jpeg";
Profileimages[145] = "/Xcryptos project /th (52).jpeg";
Profileimages[146] = "/Xcryptos project /th (53).jpeg";
Profileimages[147] = "/Xcryptos project /th (54).jpeg";
Profileimages[148] = "/Xcryptos project /th (55).jpeg";
Profileimages[149] = "/Xcryptos project /th (56).jpeg";
Profileimages[150] = "/Xcryptos project /th (57).jpeg";
Profileimages[151] = "/Xcryptos project /th (58).jpeg";
Profileimages[152] = "/Xcryptos project /th (59).jpeg";
Profileimages[153] = "/Xcryptos project /th (6).jpeg";
Profileimages[154] = "/Xcryptos project /th (60).jpeg";
Profileimages[155] = "/Xcryptos project /th (61).jpeg";
Profileimages[156] = "/Xcryptos project /th (62).jpeg";
Profileimages[157] = "/Xcryptos project /th (63).jpeg";
Profileimages[158] = "/Xcryptos project /th (64).jpeg";
Profileimages[159] = "/Xcryptos project /th (65).jpeg";
Profileimages[160] = "/Xcryptos project /th (66).jpeg";
Profileimages[161] = "/Xcryptos project /th (67).jpeg";
Profileimages[162] = "/Xcryptos project /th (68).jpeg";
Profileimages[163] = "/Xcryptos project /th (69).jpeg";
Profileimages[164] = "/Xcryptos project /th (7).jpeg";
Profileimages[165] = "/Xcryptos project /th (70).jpeg";
Profileimages[166] = "/Xcryptos project /th (71).jpeg";
Profileimages[167] = "/Xcryptos project /th (72).jpeg";
Profileimages[168] = "/Xcryptos project /th (73).jpeg";
Profileimages[169] = "/Xcryptos project /th (74).jpeg";
Profileimages[170] = "/Xcryptos project /th (75).jpeg";
Profileimages[171] = "/Xcryptos project /th (76).jpeg";
Profileimages[172] = "/Xcryptos project /th (77).jpeg";
Profileimages[173] = "/Xcryptos project /th (78).jpeg";
Profileimages[174] = "/Xcryptos project /th (79).jpeg";
Profileimages[175] = "/Xcryptos project /th (8).jpeg";
Profileimages[176] = "/Xcryptos project /th (80).jpeg";
Profileimages[177] = "/Xcryptos project /th (81).jpeg";
Profileimages[178] = "/Xcryptos project /th (82).jpeg";
Profileimages[179] = "/Xcryptos project /th (83).jpeg";
Profileimages[180] = "/Xcryptos project /th (84).jpeg";
Profileimages[181] = "/Xcryptos project /th (85).jpeg";
Profileimages[182] = "/Xcryptos project /th (86).jpeg";
Profileimages[183] = "/Xcryptos project /th (87).jpeg";
Profileimages[184] = "/Xcryptos project /th (88).jpeg";
Profileimages[185] = "/Xcryptos project /th (89).jpeg";
Profileimages[186] = "/Xcryptos project /th (9).jpeg";
Profileimages[187] = "/Xcryptos project /th.jpeg";
Profileimages[188] = "/Xcryptos project /Tron_Girl_1631389926159.jpeg";
Profileimages[189] = "/Xcryptos project /view-3d-businessman-working-laptop_23-2150709808.jpg";
Profileimages[190] = "/Xcryptos project /woman-playing-gaming-7900653-6397256.png";
Profileimages[191] = "/Xcryptos project /woman-with-bitcoins-flying-vector.jpg";
Profileimages[192] = "/Xcryptos project /woman-with-dollar-bill-her-hand-is-standing-front-pile-coins_1103290-25585.jpg";
Profileimages[193] = "/Xcryptos project /young-man-red-haired-have-found-an-idea-3d-character-illustration-png.png";
Profileimages[194] = "/Xcryptos project /young-woman-ann-attending-online-conference-3d-vector-illustration_1036687-51907.jpg";
Profileimages[195] = "/Xcryptos project /young-woman-ann-attending-online-conference-3d-vector-illustration_1036687-51945.jpg";
Profileimages[196] = "https://example.com/image47.jpg";
Profileimages[197] = "https://example.com/image48.jpg";
Profileimages[198] = "https://example.com/image49.jpg";
Profileimages[199] = "https://example.com/image50.jpg";

Profileimages[200] = "https://example.com/image200.jpg"; // Last image










// detect device informations for further recognitions stuffs
// Function to collect device information
function setCookie(name, value, days = 1) {
  const date = new Date();
  date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000); // Set expiration
  document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/`;
}

function getCookie(name) {
  const cookieArr = document.cookie.split("; ");
  for (const cookie of cookieArr) {
    const [key, value] = cookie.split("=");
    if (key === name) return value;
  }
  return null;
}

async function manageDevice() {
  // Retrieve the device ID from the cookie
  let activeDeviceId = getCookie("activeDeviceId");

  if (activeDeviceId) {
    // If an ID exists, log recognition
    console.log("Device is recognized with ID:");
    return; // Stop further execution
  }

  // If no ID exists, detect the device and assign an ID
  const deviceInfo = await detectDeviceInfo();
  activeDeviceId = generateUniqueId();
  setCookie("activeDeviceId", activeDeviceId, 1); // Store the ID in a cookie
  console.log("New Device Detected and Assigned ID:", activeDeviceId);
  console.log("Detected Device Info:", deviceInfo);
}

function generateUniqueId() {
  return `device-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

async function detectDeviceInfo() {
  const deviceInfo = {
    browser: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    connectionType: navigator.connection ? navigator.connection.effectiveType : "unknown",
    online: navigator.onLine,
    ip: await getPublicIp(),
  };
  return deviceInfo;
}

async function getPublicIp() {
  try {
    const response = await fetch("https://api64.ipify.org?format=json");
    const data = await response.json();
    return data.ip;
  } catch (err) {
    console.error("Error fetching IP:", err);
    return "Unable to fetch IP";
  }
}

// Run the manageDevice function
manageDevice();